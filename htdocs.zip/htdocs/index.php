﻿ <font size=1 color=orange> <i>이의호의 홈페이지</i></font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <font size=3> linklist : </font>&nbsp;&nbsp;&nbsp;
 <a href="test.html">  test </pre> </a> /
<a href="ultest.html"> ultest </a> /
<a href="index.php"> index </a> /
<a href="link.html"> link </a> /
<a href="table.html"> table </a> /
<a href="Tutorial.html"> Tutorial </a>
<hr>

 <img src=naver1.png width="400" height="100" alt="네이버로고" align=top> 
 
 <table width= "1150" height= "1000" border="1" bordercolor="gold">
<tr height= "10">
  <td align="right"> 
  <font color=ruby> 메일 &nbsp; 카페 &nbsp; 웹툰 &nbsp; tv &nbsp; 지식IN &nbsp; 쇼핑 &nbsp; pay &nbsp; </font> 사전 &nbsp; 뉴스 &nbsp; 증권 &nbsp; 부동산 &nbsp; 지도 &nbsp; 영화 &nbsp; 뮤직 &nbsp; 책 &nbsp; 웹툰 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type=text  name=userid placeholder="아이디" <p>
        <input type=password name=pwd placeholder="비밀번호"> 
		<input type=button value=확인하기 onclick=aaa()> </td>
  <td> &nbsp; </td>
<tr>
<tr>  
  <td>
  <img src=twise.png alt="트와이스 존예" align="" height=auto>
  &nbsp;
  </td>
<tr>
<tr>
  <td> &nbsp; </td>
<tr>
</table>


